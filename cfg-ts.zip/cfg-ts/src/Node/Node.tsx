import * as React from "react";

export interface Props {
    children?: React.ReactNode,
    btnText?: string,
    btnClick?: any,
    nodeText?: string;
}

export interface State {
}

export default class Node extends React.Component<Props, State> {

    constructor(props: Props) {
        super(props)
        this.state = {
        }
    }

    render() {
        const text = this.props.btnText;
        
        return (
            <div style={{ margin: 0, fontWeight: "normal" }}>
                {this.props.nodeText}
                <button onClick={this.props.btnClick}>{text}</button>
            </div>
        );
    }
}
