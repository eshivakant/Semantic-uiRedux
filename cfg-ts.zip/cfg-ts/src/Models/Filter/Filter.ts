export default class Filter {
    
    public Operator: string|null;
    
    public Expression: string|null;
    
    public SubFilters: Filter[]|null;

    constructor() {
        this.Operator = '';
        this.Expression = '';
        this.SubFilters = [];
        
    }
}