import * as React from "react";
import SortableTree from 'react-sortable-tree';
import 'react-sortable-tree/style.css'; // This only needs to be imported once in your app
import Node from '../Node';
//import Filter from '../Models/Filter';
import _ from 'lodash';
import './style.css'
import { string } from "prop-types";

export interface Props {
    children?: React.ReactNode
}

export interface TreeItem {
    title?: React.ReactNode;
    subtitle?: React.ReactNode;
    expanded?: boolean;
    children?: TreeItem[];
    operator?: string;
    expression?: string;
    //[x: string]: any;
}

export interface State {
    treeData: TreeItem[];
    //Models:Filter[];
}

export default class Tree extends React.Component<Props, State> {


    constructor(props: Props) {
        super(props);

        this.state = {
            treeData: [{
                title: "AND",
                subtitle: <Node nodeText="AccountInformation <> 'BNPAPAR'" btnText="Delete" btnClick={this.click.bind(this)} />,
                operator: "AND",
                expanded: true,
                expression: "AccountInformation <> 'BNPAPAR'",
                children: [{
                    title: "AND",
                    subtitle: <Node nodeText="AccountInformation <> 'BNPAPAR'" btnText="Delete" btnClick={this.click.bind(this)} />,
                    operator: "AND",
                    children: [],
                    expanded: true,
                    expression: "AccountInformation <> 'BNPAPAR'"
                }]
            }]
        };
    }

    constructSql(t: TreeItem): string {
        let op = t.operator;
        let exp = t.expression;
        let subFilter = "";
        if (t.children && t.children.length > 0)
            subFilter = "( " + t.children.map(c => this.constructSql(c)).join(" ") + " ) ";


        subFilter = subFilter.replace("  "," ");

        console.log(subFilter);

        if(subFilter.trim().startsWith("("))
        {
            let arr = subFilter.split(" ")
            let firstConjunction = _.findIndex(arr, (i:string)=>i!==" " && i!=="(");
            let conj = arr[firstConjunction];
            arr.splice(firstConjunction,1)

            arr.unshift(" ");
            arr.unshift(conj);

            subFilter = arr.join(" ");
        }


        return `${op} ${exp} ${subFilter}`;
    }

    async add() {
        const t = [...this.state.treeData];
        t.push({
            title: "AND",
            subtitle: <Node nodeText="AccountInformation <> 'BNPAPAR'" btnText="Delete" btnClick={this.click.bind(this)} />,
            operator: "AND",
            children: [],
            expanded: true,
            expression: "AccountInformation <> 'BNPAPAR'"
        });

        //this.removeConjunctionFromFirstChild(t);

        await this.setState({ treeData: t });

        let rootTreeItem: TreeItem = { children: t, operator: "", expression: "" }

        let sql = this.constructSql(rootTreeItem);

        console.log(sql);
    }

    removeConjunctionFromFirstChild(t: TreeItem[]) {
        if (t.length > 1) {
            t[0].title = " ";
            t[0].operator = "";
        }

        // t.forEach(i=>{
        //     if(i.children)
        //         this.removeConjunctionFromFirstChild(i.children)
        // });
    }


    click() {
        alert(this.state.treeData.length);
    }



    render() {

        const { treeData } = this.state;


        return (
            <div className='fullScreen'>
                <button onClick={this.add.bind(this)}>Add</button>
                <SortableTree
                    treeData={treeData}
                    onChange={treeData => this.setState({ treeData: treeData })}
                />
            </div>
        );
    }
}
